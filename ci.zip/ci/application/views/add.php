<form method="POST">
	<div class="form-group">
	    <label>Nama Posyandu</label>
		<input type="text" name="nama" class="form-control" placeholder="Nama Posyandu">
	</div>
	<div class="form-group">
		<label>Alamat</label>
		<input type="text" name="alamat" class="form-control" placeholder="Alamat Posyandu">
	</div>
	<button type="submit" class="btn btn-primary" name="submit" value="1!1">Simpan</button>
</form>